<?php

class Users extends CI_Controller
{

    public function index()
    {
        $this->load->view('search');
    }

    public function user($data)
    {
        $this->load->view('search', $data);
    }
}
